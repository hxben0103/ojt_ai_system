import 'package:flutter/material.dart';

/// Centralized app theme for consistent styling across all dashboards
class AppTheme {
  // Primary colors for each role
  static const Color studentPrimary = Color(0xFF2196F3); // Blue
  static const Color coordinatorPrimary = Color(0xFF9C27B0); // Purple
  static const Color supervisorPrimary = Color(0xFF009688); // Teal
  static const Color adminPrimary = Color(0xFFF44336); // Red

  // Common colors
  static const Color successColor = Color(0xFF4CAF50);
  static const Color warningColor = Color(0xFFFF9800);
  static const Color errorColor = Color(0xFFF44336);
  static const Color infoColor = Color(0xFF2196F3);

  // Text styles
  static const TextStyle heading1 = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    color: Colors.black87,
  );

  static const TextStyle heading2 = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.bold,
    color: Colors.black87,
  );

  static const TextStyle heading3 = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: Colors.black87,
  );

  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    color: Colors.black87,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    color: Colors.black87,
  );

  static const TextStyle bodySmall = TextStyle(
    fontSize: 12,
    color: Colors.black54,
  );

  static const TextStyle caption = TextStyle(
    fontSize: 11,
    color: Colors.black38,
  );

  // Spacing constants
  static const double spacing2 = 2.0;
  static const double spacing4 = 4.0;
  static const double spacing6 = 6.0;
  static const double spacing8 = 8.0;
  static const double spacing12 = 12.0;
  static const double spacing16 = 16.0;
  static const double spacing20 = 20.0;
  static const double spacing24 = 24.0;
  static const double spacing32 = 32.0;

  // Border radius
  static const double borderRadiusSmall = 8.0;
  static const double borderRadiusMedium = 12.0;
  static const double borderRadiusLarge = 16.0;

  // Get role-specific primary color
  static Color getRoleColor(String role) {
    final roleLower = role.toLowerCase();
    if (roleLower.contains('student')) return studentPrimary;
    if (roleLower.contains('coordinator')) return coordinatorPrimary;
    if (roleLower.contains('supervisor')) return supervisorPrimary;
    if (roleLower.contains('admin')) return adminPrimary;
    return Colors.indigo; // Default
  }

  // Create primary button style
  static ButtonStyle primaryButtonStyle(Color primaryColor) {
    return ElevatedButton.styleFrom(
      backgroundColor: primaryColor,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadiusMedium),
      ),
      elevation: 2,
    );
  }

  // Create secondary button style
  static ButtonStyle secondaryButtonStyle(Color primaryColor) {
    return OutlinedButton.styleFrom(
      foregroundColor: primaryColor,
      side: BorderSide(color: primaryColor, width: 1.5),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(borderRadiusMedium),
      ),
    );
  }
}

