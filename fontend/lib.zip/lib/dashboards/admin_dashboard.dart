import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/user.dart';
import '../services/auth_service.dart';
import '../widgets/role_dashboard.dart';
import '../widgets/role_guard.dart';
import '../widgets/stat_card.dart';
import '../widgets/section_header.dart';
import '../core/app_theme.dart';
import '../screens/login_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  bool _isLoadingData = true;
  String? _errorMessage;
  List<User> _pendingCoordinators = [];
  int _totalUsers = 0;
  int _activeUsers = 0;
  int _pendingUsers = 0;
  int _coordinatorCount = 0;
  final Set<int> _processing = {};
  final DateFormat _dateFormat = DateFormat('MMM d, yyyy');

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    try {
      setState(() {
        _isLoadingData = true;
        _errorMessage = null;
      });

      final pendingUsers = await AuthService.getPendingUsers();
      final allUsers = await AuthService.getAllUsers();

      setState(() {
        _pendingCoordinators =
            pendingUsers.where((user) => user.role == 'Coordinator').toList();
        _totalUsers = allUsers.length;
        _activeUsers =
            allUsers.where((user) => user.status == 'Active').length;
        _pendingUsers =
            allUsers.where((user) => user.status == 'Pending').length;
        _coordinatorCount =
            allUsers.where((user) => user.role == 'Coordinator').length;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingData = false;
        });
      }
    }
  }

  Future<void> _handleDecision(User user, bool approve) async {
    if (user.userId == null) return;
    setState(() {
      _processing.add(user.userId!);
    });
    try {
      if (approve) {
        await AuthService.approveUser(user.userId!);
      } else {
        await AuthService.rejectUser(user.userId!);
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              approve
                  ? 'Approved ${user.fullName}'
                  : 'Rejected ${user.fullName}',
            ),
          ),
        );
      }
      await _loadDashboardData();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Action failed: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _processing.remove(user.userId);
        });
      }
    }
  }

  Future<void> _logout(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Confirm Logout"),
        content: const Text("Are you sure you want to log out?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: AppTheme.primaryButtonStyle(AppTheme.adminPrimary),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text("Logout"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await AuthService.logout();
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    }
  }

  List<Widget> _buildCustomActions(BuildContext context) {
    final widgets = <Widget>[
      _buildHeaderCard(context),
      const SizedBox(height: AppTheme.spacing8),
    ];

    if (_isLoadingData) {
      widgets.add(_buildLoadingCard());
    } else if (_errorMessage != null) {
      widgets.add(_buildErrorCard());
    } else {
      widgets
        ..add(SectionHeader(
          title: 'System Overview',
          padding: const EdgeInsets.fromLTRB(
            AppTheme.spacing16,
            AppTheme.spacing24,
            AppTheme.spacing16,
            AppTheme.spacing8,
          ),
        ))
        ..add(_buildStatsSection(context))
        ..add(const SizedBox(height: AppTheme.spacing12))
        ..add(SectionHeader(
          title: 'Pending Approvals',
          subtitle: '${_pendingCoordinators.length} coordinator request(s)',
          padding: const EdgeInsets.fromLTRB(
            AppTheme.spacing16,
            AppTheme.spacing24,
            AppTheme.spacing16,
            AppTheme.spacing8,
          ),
        ))
        ..add(_buildPendingSection(context))
        ..add(const SizedBox(height: AppTheme.spacing16));
    }

    widgets.add(_buildLogoutCard(context));
    widgets.add(const SizedBox(height: AppTheme.spacing24));
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return RoleGuard(
      allowedRoles: const ['admin'],
      builder: (ctx, user) => RoleDashboard(
        title: "Admin Dashboard",
        color: AppTheme.adminPrimary,
        tasks: const [],
        customActions: _buildCustomActions(ctx),
      ),
    );
  }

  Widget _buildHeaderCard(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.adminPrimary,
            AppTheme.adminPrimary.withOpacity(0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: [
          BoxShadow(
            color: AppTheme.adminPrimary.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          )
        ],
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      padding: const EdgeInsets.all(AppTheme.spacing20),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(AppTheme.borderRadiusMedium),
            ),
            child: const Icon(
              Icons.admin_panel_settings,
              size: 32,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: AppTheme.spacing16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Administrative Overview",
                  style: AppTheme.heading2.copyWith(color: Colors.white),
                ),
                const SizedBox(height: AppTheme.spacing4),
                Text(
                  "System Management & User Approvals",
                  style: AppTheme.bodyMedium.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: _isLoadingData ? null : _loadDashboardData,
            icon: const Icon(Icons.refresh, color: Colors.white),
            tooltip: 'Refresh',
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: const Padding(
        padding: EdgeInsets.all(AppTheme.spacing24),
        child: Center(
          child: Column(
            children: [
              CircularProgressIndicator(),
              SizedBox(height: AppTheme.spacing12),
              Text("Fetching latest data..."),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorCard() {
    return Card(
      elevation: 2,
      color: Colors.red.shade50,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spacing16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.error, color: Colors.red),
                const SizedBox(width: AppTheme.spacing8),
                Expanded(
                  child: Text(
                    "Unable to load dashboard data",
                    style: AppTheme.bodyLarge.copyWith(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppTheme.spacing8),
            Text(
              _errorMessage ?? 'Unknown error',
              style: AppTheme.bodySmall.copyWith(color: Colors.red),
            ),
            const SizedBox(height: AppTheme.spacing12),
            ElevatedButton.icon(
              onPressed: _loadDashboardData,
              icon: const Icon(Icons.refresh),
              label: const Text("Retry"),
              style: AppTheme.primaryButtonStyle(AppTheme.errorColor),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsSection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: StatCard(
                  title: 'Total Users',
                  value: '$_totalUsers',
                  icon: Icons.group,
                  color: AppTheme.adminPrimary,
                ),
              ),
              const SizedBox(width: AppTheme.spacing12),
              Expanded(
                child: StatCard(
                  title: 'Active Users',
                  value: '$_activeUsers',
                  icon: Icons.verified_user,
                  color: AppTheme.successColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppTheme.spacing12),
          Row(
            children: [
              Expanded(
                child: StatCard(
                  title: 'Pending Users',
                  value: '$_pendingUsers',
                  icon: Icons.pending_actions,
                  color: AppTheme.warningColor,
                ),
              ),
              const SizedBox(width: AppTheme.spacing12),
              Expanded(
                child: StatCard(
                  title: 'Coordinators',
                  value: '$_coordinatorCount',
                  icon: Icons.school,
                  color: AppTheme.coordinatorPrimary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPendingSection(BuildContext context) {
    if (_pendingCoordinators.isEmpty) {
      return Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        ),
        margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.spacing24),
          child: Center(
            child: Column(
              children: [
                Icon(
                  Icons.check_circle_outline,
                  size: 64,
                  color: AppTheme.successColor.withOpacity(0.5),
                ),
                const SizedBox(height: AppTheme.spacing12),
                Text(
                  "No pending coordinator approvals",
                  style: AppTheme.bodyLarge.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppTheme.spacing4),
                Text(
                  "You're all caught up!",
                  style: AppTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: Padding(
        padding: const EdgeInsets.all(AppTheme.spacing16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: AppTheme.spacing8),
            ..._pendingCoordinators.map((user) {
              final processing = user.userId != null &&
                  _processing.contains(user.userId);
              return Card(
                elevation: 1,
                margin: const EdgeInsets.only(bottom: AppTheme.spacing12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppTheme.borderRadiusMedium),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(AppTheme.spacing12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            backgroundColor: AppTheme.adminPrimary.withOpacity(0.1),
                            radius: 24,
                            child: Text(
                              user.fullName.split(" ").where((e) => e.isNotEmpty).map((e) => e[0]).take(2).join(),
                              style: TextStyle(
                                color: AppTheme.adminPrimary,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                          const SizedBox(width: AppTheme.spacing12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  user.fullName,
                                  style: AppTheme.bodyLarge.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: AppTheme.spacing4),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.email,
                                      size: 14,
                                      color: Colors.grey[600],
                                    ),
                                    const SizedBox(width: AppTheme.spacing4),
                                    Expanded(
                                      child: Text(
                                        user.email,
                                        style: AppTheme.bodySmall,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                if (user.contactNumber != null &&
                                    user.contactNumber!.isNotEmpty) ...[
                                  const SizedBox(height: AppTheme.spacing4),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.phone,
                                        size: 14,
                                        color: Colors.grey[600],
                                      ),
                                      const SizedBox(width: AppTheme.spacing4),
                                      Text(
                                        user.contactNumber!,
                                        style: AppTheme.bodySmall,
                                      ),
                                    ],
                                  ),
                                ],
                                if (user.dateCreated != null) ...[
                                  const SizedBox(height: AppTheme.spacing4),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.calendar_today,
                                        size: 14,
                                        color: Colors.grey[600],
                                      ),
                                      const SizedBox(width: AppTheme.spacing4),
                                      Text(
                                        "Applied on ${_dateFormat.format(user.dateCreated!)}",
                                        style: AppTheme.bodySmall,
                                      ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(width: AppTheme.spacing8),
                          Chip(
                            label: const Text("Pending"),
                            backgroundColor: AppTheme.warningColor.withOpacity(0.2),
                            labelStyle: TextStyle(
                              color: AppTheme.warningColor,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppTheme.spacing8,
                              vertical: AppTheme.spacing4,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppTheme.spacing12),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: processing
                                  ? null
                                  : () => _handleDecision(user, true),
                              icon: const Icon(Icons.check, size: 18),
                              label: const Text("Approve"),
                              style: AppTheme.primaryButtonStyle(AppTheme.successColor),
                            ),
                          ),
                          const SizedBox(width: AppTheme.spacing12),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: processing
                                  ? null
                                  : () => _handleDecision(user, false),
                              icon: const Icon(Icons.close, size: 18),
                              label: const Text("Reject"),
                              style: AppTheme.secondaryButtonStyle(AppTheme.errorColor),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildLogoutCard(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        onTap: () => _logout(context),
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.spacing16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.errorColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(AppTheme.borderRadiusMedium),
                ),
                child: Icon(
                  Icons.logout,
                  color: AppTheme.errorColor,
                  size: 24,
                ),
              ),
              const SizedBox(width: AppTheme.spacing16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Logout",
                      style: AppTheme.bodyLarge.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: AppTheme.spacing4),
                    Text(
                      "Sign out of the admin console",
                      style: AppTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: Colors.grey[400],
                size: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
