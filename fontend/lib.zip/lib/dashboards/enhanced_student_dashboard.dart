import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/dashboard_card.dart';
// Risk label not shown to students; progress + AI explanation used instead
import '../widgets/chatbot_screen.dart';
import '../core/app_theme.dart';
import '../services/attendance_service.dart';
import '../services/prediction_service.dart';
import '../services/auth_service.dart';
import '../services/ojt_service.dart';
import '../models/user.dart';
import 'student_attendance_screen.dart';
import 'student_dtr_view_screen.dart';
import '../screens/login_screen.dart';

/// Enhanced Student Dashboard with AI risk level, attendance status, and chatbot access
class EnhancedStudentDashboard extends StatefulWidget {
  const EnhancedStudentDashboard({super.key});

  @override
  State<EnhancedStudentDashboard> createState() => _EnhancedStudentDashboardState();
}

class _EnhancedStudentDashboardState extends State<EnhancedStudentDashboard> {
  bool _isLoading = true;
  String? _errorMessage;
  
  // Student data
  User? _currentUser;
  int? _studentUserId;
  
  // Attendance data
  String? _todayAttendanceStatus; // e.g., "TIME IN at 8:05 AM" or "Not yet timed in"
  String? _lastActionTime;
  
  // Hours data
  int? _completedHours;
  int? _requiredHours;
  bool _hoursLoading = false;
  String? _hoursError;
  
  // AI Risk Level
  String? _aiRiskLevel; // LOW, MEDIUM, HIGH
  String? _riskLabel; // Short label/description
  bool _riskLoading = false;
  String? _riskError;
  
  // Attendance error
  String? _attendanceError;

  @override
  void initState() {
    super.initState();
    _loadDashboardData();
  }

  Future<void> _loadDashboardData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Load current user
      final user = await AuthService.getCurrentUser();
      if (user == null) {
        setState(() {
          _errorMessage = 'User not logged in';
          _isLoading = false;
        });
        return;
      }

      setState(() {
        _currentUser = user;
        _studentUserId = user.userId;
      });

      // Load attendance data, hours, AI risk, and OJT record in parallel
      await Future.wait([
        _loadTodayAttendance(),
        _loadOjtRecordAndHours(),
        _loadAIRiskLevel(),
      ]);
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load dashboard data: ${e.toString()}';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _loadTodayAttendance() async {
    if (_studentUserId == null) return;

    try {
      final attendance = await AttendanceService.getTodayAttendance(_studentUserId!);
      if (attendance != null && attendance.timeIn != null) {
        setState(() {
          _todayAttendanceStatus = 'TIME IN at ${_formatTime(attendance.timeIn!)}';
          _lastActionTime = attendance.timeIn;
          _attendanceError = null;
          if (attendance.timeOut != null) {
            _todayAttendanceStatus = 'TIME OUT at ${_formatTime(attendance.timeOut!)}';
            _lastActionTime = attendance.timeOut;
          }
        });
      } else {
        setState(() {
          _todayAttendanceStatus = 'Not yet timed in';
          _lastActionTime = null;
          _attendanceError = null;
        });
      }
    } catch (e) {
      setState(() {
        _attendanceError = 'Unable to load attendance data';
        _todayAttendanceStatus = 'Attendance data unavailable';
      });
      print('Error loading today attendance: $e');
    }
  }

  Future<void> _loadOjtRecordAndHours() async {
    if (_studentUserId == null) return;

    setState(() {
      _hoursLoading = true;
      _hoursError = null;
    });

    try {
      // First, get OJT record to find required hours
      final ojtRecords = await OjtService.getOjtRecords(studentId: _studentUserId);
      
      if (ojtRecords.isNotEmpty) {
        final ojtRecord = ojtRecords.first;
        final requiredHoursFromOjt = ojtRecord.requiredHours;
        
        // Then get attendance summary for completed hours
        try {
          final summaryList = await AttendanceService.getSummary(studentId: _studentUserId);
          if (summaryList.isNotEmpty) {
            final summary = summaryList[0];
            setState(() {
              _completedHours = summary['total_hours']?.toInt() ?? 0;
              _requiredHours = requiredHoursFromOjt ?? summary['required_hours']?.toInt();
            });
          } else {
            // No attendance summary yet, but we have OJT record
            setState(() {
              _completedHours = 0;
              _requiredHours = requiredHoursFromOjt;
            });
          }
        } catch (e) {
          // If attendance summary fails, still use OJT record for required hours
          setState(() {
            _completedHours = null;
            _requiredHours = requiredHoursFromOjt;
            _hoursError = 'Unable to load completed hours';
          });
          print('Error loading attendance summary: $e');
        }
      } else {
        // No OJT record found
        setState(() {
          _completedHours = null;
          _requiredHours = null;
          _hoursError = 'No OJT record found. Please contact your coordinator.';
        });
      }
    } catch (e) {
      setState(() {
        _completedHours = null;
        _requiredHours = null;
        _hoursError = 'Unable to load hours data';
      });
      print('Error loading OJT record and hours: $e');
    } finally {
      if (mounted) {
        setState(() {
          _hoursLoading = false;
        });
      }
    }
  }

  Future<void> _loadAIRiskLevel() async {
    if (_studentUserId == null) return;

    setState(() {
      _riskLoading = true;
      _riskError = null;
    });

    try {
      final prediction = await PredictionService.getDailyPrediction(_studentUserId!);
      final mlPrediction = prediction['ai_prediction']?['ml_prediction'] as Map<String, dynamic>?;
      
      if (mlPrediction != null) {
        setState(() {
          _aiRiskLevel = mlPrediction['risk_level'] as String;
          _riskLabel = mlPrediction['recommendation'] as String?;
          _riskError = null;
        });
      } else {
        setState(() {
          _aiRiskLevel = null;
          _riskLabel = null;
          _riskError = 'Risk assessment data not available';
        });
      }
    } catch (e) {
      setState(() {
        _aiRiskLevel = null;
        _riskLabel = null;
        _riskError = 'Unable to load risk assessment';
      });
      print('Error loading AI risk: $e');
    } finally {
      if (mounted) {
        setState(() {
          _riskLoading = false;
        });
      }
    }
  }

  String _formatTime(String timeStr) {
    try {
      final time = TimeOfDay.fromDateTime(DateFormat('HH:mm:ss').parse(timeStr));
      return DateFormat('hh:mm a').format(
        DateTime(2024, 1, 1, time.hour, time.minute),
      );
    } catch (e) {
      return timeStr;
    }
  }

  void _openChatbot() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ChatBotScreen(),
      ),
    );
  }

  void _navigateToAttendance() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const StudentAttendanceScreen(),
      ),
    ).then((_) => _loadDashboardData()); // Refresh after returning
  }

  Future<void> _navigateToDTR() async {
    if (_studentUserId == null) return;

    try {
      // Load DTR records
      final attendanceRecords = await AttendanceService.getAttendance(studentId: _studentUserId);
      final dtrRecords = attendanceRecords.map((a) => {
        'date': a.date,
        'time_in': a.timeIn,
        'time_out': a.timeOut,
        'total_hours': a.totalHours,
        'verified': a.verified ?? false,
      }).toList();

      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => StudentDTRViewScreen(
              studentName: _currentUser?.fullName ?? 'Student',
              studentId: _currentUser?.studentId ?? _currentUser?.email ?? 'N/A',
              course: _currentUser?.course ?? 'N/A',
              dtrRecords: dtrRecords,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Unable to load DTR records: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              Text(
                'Loading dashboard...',
                style: AppTheme.bodyMedium,
              ),
            ],
          ),
        ),
      );
    }

    if (_errorMessage != null && _currentUser == null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 64, color: Colors.red[300]),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                style: AppTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
                child: const Text('Go to Login'),
              ),
            ],
          ),
        ),
      );
    }

    final primaryColor = AppTheme.getRoleColor('student');

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text('Student Dashboard'),
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadDashboardData,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadDashboardData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(AppTheme.spacing16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Header
              Text(
                'Welcome, ${_currentUser?.fullName ?? "Student"}',
                style: AppTheme.heading1.copyWith(color: primaryColor),
              ),
              const SizedBox(height: AppTheme.spacing8),
              Text(
                'Here\'s your OJT overview',
                style: AppTheme.bodyMedium.copyWith(color: Colors.grey[600]),
              ),
              const SizedBox(height: AppTheme.spacing24),

              // Today's Attendance Status Card
              DashboardCard(
                title: "Today's Attendance Status",
                subtitle: _attendanceError != null
                    ? _attendanceError!
                    : (_todayAttendanceStatus ?? 'Loading...'),
                leading: _attendanceError != null
                    ? Icon(Icons.error_outline, color: Colors.red[300], size: 32)
                    : Icon(
                        _todayAttendanceStatus?.contains('TIME IN') == true
                            ? Icons.check_circle
                            : Icons.schedule,
                        color: _todayAttendanceStatus?.contains('TIME IN') == true
                            ? AppTheme.successColor
                            : Colors.orange,
                        size: 32,
                      ),
                backgroundColor: Colors.white,
              ),

              // Progress & AI explanation (no risk label for students)
              DashboardCard(
                title: 'Progress & AI Insight',
                subtitle: _riskLoading
                    ? 'Loading...'
                    : (_riskError != null
                        ? _riskError!
                        : (_riskLabel ?? (_aiRiskLevel != null ? 'On track / Needs attention' : 'No insight data yet'))),
                leading: _riskLoading
                    ? const SizedBox(
                        width: 32,
                        height: 32,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : _riskError != null
                        ? Icon(Icons.error_outline, color: Colors.red[300], size: 32)
                        : (_aiRiskLevel != null
                            ? Icon(
                                _aiRiskLevel == 'LOW'
                                    ? Icons.trending_up
                                    : Icons.info_outline,
                                color: _aiRiskLevel == 'LOW'
                                    ? Colors.green
                                    : Colors.orange,
                                size: 32,
                              )
                            : Icon(Icons.info_outline, color: Colors.grey[400], size: 32)),
                backgroundColor: Colors.white,
              ),

              // Hours Progress Card
              DashboardCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'OJT Hours Progress',
                          style: AppTheme.heading3,
                        ),
                        _hoursLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : _hoursError != null
                                ? Icon(Icons.error_outline, color: Colors.red[300], size: 20)
                                : (_completedHours != null && _requiredHours != null)
                                    ? Text(
                                        '$_completedHours / $_requiredHours hrs',
                                        style: AppTheme.bodyMedium.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: primaryColor,
                                        ),
                                      )
                                    : const Text(
                                        'N/A',
                                        style: AppTheme.bodyMedium,
                                      ),
                      ],
                    ),
                    if (_hoursError != null) ...[
                      const SizedBox(height: AppTheme.spacing8),
                      Text(
                        _hoursError!,
                        style: AppTheme.bodySmall.copyWith(color: Colors.red[600]),
                      ),
                    ] else if (_completedHours != null && _requiredHours != null) ...[
                      const SizedBox(height: AppTheme.spacing12),
                      LinearProgressIndicator(
                        value: _requiredHours! > 0
                            ? (_completedHours! / _requiredHours!).clamp(0.0, 1.0)
                            : 0.0,
                        backgroundColor: Colors.grey[200],
                        valueColor: AlwaysStoppedAnimation<Color>(primaryColor),
                        minHeight: 12,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      const SizedBox(height: AppTheme.spacing8),
                      Text(
                        _requiredHours! > _completedHours!
                            ? '${_requiredHours! - _completedHours!} hours remaining'
                            : 'Required hours completed!',
                        style: AppTheme.bodySmall,
                      ),
                    ] else if (_hoursLoading) ...[
                      const SizedBox(height: AppTheme.spacing12),
                      const LinearProgressIndicator(),
                    ] else ...[
                      const SizedBox(height: AppTheme.spacing8),
                      Text(
                        'Hours data not available',
                        style: AppTheme.bodySmall.copyWith(color: Colors.grey[600]),
                      ),
                    ],
                  ],
                ),
                backgroundColor: Colors.white,
              ),

              const SizedBox(height: AppTheme.spacing16),

              // Action Buttons
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _navigateToAttendance,
                  icon: const Icon(Icons.camera_alt),
                  label: const Text('Record Attendance (Time In/Out)'),
                  style: AppTheme.primaryButtonStyle(primaryColor).copyWith(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),

              const SizedBox(height: AppTheme.spacing12),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _openChatbot,
                  icon: const Icon(Icons.chat_bubble_outline),
                  label: const Text('Open OJT Chatbot'),
                  style: AppTheme.primaryButtonStyle(primaryColor).copyWith(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),

              const SizedBox(height: AppTheme.spacing32),

              // Quick Actions Section
              Text(
                'Quick Actions',
                style: AppTheme.heading2,
              ),
              const SizedBox(height: AppTheme.spacing16),

              DashboardCard(
                title: 'View DTR',
                subtitle: 'Check your Daily Time Record',
                leading: const Icon(Icons.calendar_today, color: AppTheme.infoColor),
                onTap: () {
                  // Load DTR records and navigate
                  _navigateToDTR();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

