import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/role_dashboard.dart';
import '../widgets/role_guard.dart';
import '../widgets/stat_card.dart';
import '../widgets/section_header.dart';
import '../widgets/info_tile.dart';
import '../core/app_theme.dart';
import 'supervisor_student_monitor.dart';
import 'supervisor_attendance_verification_screen.dart';
import 'supervisor_daily_tasks_review_screen.dart';
import 'package:flutter_application_1/screens/login_screen.dart';
import '../services/auth_service.dart';
import '../services/ojt_service.dart';
import '../services/evaluation_service.dart';
import '../models/user.dart';
import '../models/ojt_record.dart';
import '../screens/supervisor/supervisor_evaluation_form_screen.dart';

class SupervisorDashboard extends StatefulWidget {
  const SupervisorDashboard({super.key});

  @override
  State<SupervisorDashboard> createState() => _SupervisorDashboardState();
}

class _SupervisorDashboardState extends State<SupervisorDashboard> {
  // Profile info will be loaded from API
  String fullName = "Loading...";
  String idNumber = "N/A";
  String office = "N/A";
  String position = "Industry Supervisor";
  bool _isLoading = true;
  bool _isLoadingStudents = true;

  // Dashboard data
  List<OjtRecord> _assignedStudents = [];
  int _pendingEvaluations = 0;
  int _totalAssigned = 0;

  @override
  void initState() {
    super.initState();
    _loadProfile();
    _loadAssignedStudents();
  }

  Future<void> _loadProfile() async {
    try {
      final user = await AuthService.getCurrentUser();
      if (user != null) {
        setState(() {
          fullName = user.fullName;
          // Use actual user ID for supervisors instead of student-specific fields
          idNumber = user.userId?.toString() ?? user.email;
          office = user.course ?? "N/A";
          position = user.role;
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadAssignedStudents() async {
    try {
      setState(() {
        _isLoadingStudents = true;
      });

      final currentUser = await AuthService.getCurrentUser();
      if (currentUser?.userId == null) {
        setState(() {
          _isLoadingStudents = false;
        });
        return;
      }

      final supervisorId = currentUser!.userId!;
      debugPrint('[SupervisorDashboard] Loading assigned students for supervisor ID: $supervisorId');

      // Get ALL OJT records assigned to this supervisor (Active, Ongoing, etc.)
      // Don't filter by status to count all assigned students
      final ojtRecords = await OjtService.getOjtRecords(
        supervisorId: supervisorId,
        // Remove status filter to get all assigned students
      );

      debugPrint('[SupervisorDashboard] Found ${ojtRecords.length} assigned student(s)');

      // Count pending evaluations
      int pendingCount = 0;
      for (final record in ojtRecords) {
        try {
          final evaluations = await EvaluationService.getEvaluations(
            studentId: record.studentId,
            supervisorId: supervisorId,
          );
          // Consider evaluation pending if there is no COMPLETED evaluation yet
          final hasCompleted = evaluations.any(
            (e) => (e.status ?? '').toLowerCase() == 'completed',
          );
          if (!hasCompleted) {
            pendingCount++;
          }
        } catch (e) {
          debugPrint('[SupervisorDashboard] Error checking evaluations for student ${record.studentId}: $e');
          // Count as pending if we can't check (safer to show as pending)
          pendingCount++;
        }
      }

      debugPrint('[SupervisorDashboard] Total assigned: ${ojtRecords.length}, Pending evaluations: $pendingCount');

      setState(() {
        _assignedStudents = ojtRecords;
        _totalAssigned = ojtRecords.length;
        _pendingEvaluations = pendingCount;
        _isLoadingStudents = false;
      });
    } catch (e, stackTrace) {
      debugPrint('[SupervisorDashboard] Error loading assigned students: $e');
      debugPrint('[SupervisorDashboard] Stack trace: $stackTrace');
      setState(() {
        _assignedStudents = [];
        _totalAssigned = 0;
        _pendingEvaluations = 0;
        _isLoadingStudents = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return RoleGuard(
      allowedRoles: const ['supervisor', 'industry supervisor'],
      builder: (ctx, user) => _buildSupervisorDashboard(ctx),
    );
  }

  Widget _buildSupervisorDashboard(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return RoleDashboard(
      title: "Industry Supervisor Dashboard",
      color: AppTheme.supervisorPrimary,
      tasks: const [],
      customActions: [
        _buildAnimated(_buildProfileHeader(), 0),
        
        // Statistics Section
        _buildAnimated(
          SectionHeader(
            title: 'Overview',
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          ),
          50,
        ),
        _buildAnimated(_buildStatsRow(), 100),
        
        // Assigned Students Section
        if (_assignedStudents.isNotEmpty) ...[
          _buildAnimated(
            SectionHeader(
              title: 'Assigned Students',
              subtitle: '${_assignedStudents.length} student(s)',
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            ),
            150,
          ),
          ..._assignedStudents.take(3).toList().asMap().entries.map((entry) => 
            _buildAnimated(
              _buildStudentTile(_assignedStudents[entry.key]),
              200 + ((entry.key as int) * 50),
            ),
          ),
          if (_assignedStudents.length > 3)
            _buildAnimated(
              _buildViewAllStudentsCard(),
              350,
            ),
        ],
        
        // Quick Actions Section
        _buildAnimated(
          SectionHeader(
            title: 'Quick Actions',
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          ),
          400,
        ),
        _buildAnimated(_buildFeatureCard(
          icon: Icons.assignment,
          title: "Submit Evaluations",
          subtitle: "Evaluate students and submit feedback",
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const SupervisorEvaluationFormScreen(),
              ),
            );
          },
        ), 450),
        _buildAnimated(_buildFeatureCard(
          icon: Icons.trending_up,
          title: "Monitor Student Progress",
          subtitle: "View students' OJT hours and attendance",
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const SupervisorStudentMonitorScreen(),
              ),
            );
          },
        ), 500),
        _buildAnimated(_buildFeatureCard(
          icon: Icons.verified_user,
          title: "Verify Student Attendance",
          subtitle: "Flag and verify student attendance records for transparency",
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const SupervisorAttendanceVerificationScreen(),
              ),
            );
          },
        ), 550),
        _buildAnimated(_buildFeatureCard(
          icon: Icons.task_alt,
          title: "Review Daily Tasks",
          subtitle: "Approve or reject student daily task submissions",
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const SupervisorDailyTasksReviewScreen(),
              ),
            );
          },
        ), 600),

        // ✅ Logout Card Added
        _buildAnimated(_buildLogoutCard(context), 650),
      ],
    );
  }

  

  // --- Animated Wrapper ---
  Widget _buildAnimated(Widget child, int delay) {
    return Animate(
      effects: [
        FadeEffect(duration: 600.ms, delay: delay.ms),
        SlideEffect(begin: const Offset(0, 0.2), end: Offset.zero, delay: delay.ms),
      ],
      child: child,
    );
  }

  // --- Statistics Row ---
  Widget _buildStatsRow() {
    if (_isLoadingStudents) {
      return const Padding(
        padding: EdgeInsets.all(AppTheme.spacing16),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: Row(
        children: [
          Expanded(
            child: StatCard(
              title: 'Assigned',
              value: '$_totalAssigned',
              icon: Icons.people,
              color: AppTheme.supervisorPrimary,
            ),
          ),
          const SizedBox(width: AppTheme.spacing12),
          Expanded(
            child: StatCard(
              title: 'Pending Eval',
              value: '$_pendingEvaluations',
              icon: Icons.assignment,
              color: AppTheme.warningColor,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SupervisorEvaluationFormScreen(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // --- Student Tile ---
  Widget _buildStudentTile(OjtRecord record) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: StudentInfoTile(
        studentName: record.studentName ?? 'Unknown',
        course: record.companyName,
        company: record.companyName,
        requiredHours: record.requiredHours,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const SupervisorStudentMonitorScreen(),
            ),
          );
        },
      ),
    );
  }

  // --- View All Students Card ---
  Widget _buildViewAllStudentsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const SupervisorStudentMonitorScreen(),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.spacing16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'View All ${_assignedStudents.length} Students',
                style: AppTheme.bodyLarge.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.supervisorPrimary,
                ),
              ),
              const SizedBox(width: AppTheme.spacing8),
              Icon(
                Icons.arrow_forward,
                color: AppTheme.supervisorPrimary,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Profile Header with Gradient & Shadow ---
  Widget _buildProfileHeader() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.supervisorPrimary,
            AppTheme.supervisorPrimary.withOpacity(0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        boxShadow: [
          BoxShadow(
            color: AppTheme.supervisorPrimary.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      margin: const EdgeInsets.symmetric(horizontal: AppTheme.spacing16),
      padding: const EdgeInsets.all(AppTheme.spacing16),
      child: Row(
        children: [
          CircleAvatar(
            radius: 42,
            backgroundColor: Colors.white,
            child: Text(
              fullName.split(" ").where((e) => e.isNotEmpty).map((e) => e[0]).take(2).join(),
              style: TextStyle(
                color: AppTheme.supervisorPrimary,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ).animate().scale(duration: 600.ms, curve: Curves.easeOutBack),
          const SizedBox(width: AppTheme.spacing16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fullName,
                  style: AppTheme.heading2.copyWith(color: Colors.white),
                ),
                const SizedBox(height: AppTheme.spacing4),
                Text(
                  "ID: $idNumber",
                  style: AppTheme.bodyMedium.copyWith(color: Colors.white70),
                ),
                Text(
                  "Office: $office",
                  style: AppTheme.bodyMedium.copyWith(color: Colors.white70),
                ),
                Text(
                  "Position: $position",
                  style: AppTheme.bodyMedium.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- Reusable Feature Card ---
  Widget _buildFeatureCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 2,
      shadowColor: AppTheme.supervisorPrimary.withOpacity(0.2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
      ),
      margin: const EdgeInsets.symmetric(
        horizontal: AppTheme.spacing16,
        vertical: AppTheme.spacing8,
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppTheme.borderRadiusLarge),
        onTap: onTap,
        splashColor: AppTheme.supervisorPrimary.withOpacity(0.2),
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.spacing16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.supervisorPrimary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(AppTheme.borderRadiusMedium),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.supervisorPrimary,
                  size: 24,
                ),
              ),
              const SizedBox(width: AppTheme.spacing16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: AppTheme.bodyLarge.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: AppTheme.spacing4),
                    Text(
                      subtitle,
                      style: AppTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: Colors.grey[400],
                size: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }

      // --- Logout Card (with White Background Loading Animation) ---
  Widget _buildLogoutCard(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      shadowColor: AppTheme.supervisorPrimary.withOpacity(0.3),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () async {
          final confirm = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text("Confirm Logout"),
              content:
                  const Text("Are you sure you want to log out of your account?"),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  style: AppTheme.primaryButtonStyle(AppTheme.supervisorPrimary),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text("Logout"),
                ),
              ],
            ),
          );

          if (confirm == true) {
            // ✅ Show loading animation dialog with white background
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (ctx) => Scaffold(
                backgroundColor: Colors.white, // White background
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/images/logo.gif', // your logo or loading GIF
                        height: 200,
                      )
                          .animate()
                          .fadeIn(duration: 900.ms)
                          .scale(duration: 900.ms),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            );

            // Simulate delay for logout
            await Future.delayed(const Duration(seconds: 2));

            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();

            if (context.mounted) {
              Navigator.pop(context); // Close loading dialog
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
                (route) => false,
              );
            }
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(AppTheme.spacing16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.errorColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(AppTheme.borderRadiusMedium),
                ),
                child: Icon(
                  Icons.logout,
                  color: AppTheme.errorColor,
                  size: 24,
                ),
              ),
              const SizedBox(width: AppTheme.spacing16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Log Out",
                      style: AppTheme.bodyLarge.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: AppTheme.spacing4),
                    Text(
                      "Sign out from your account",
                      style: AppTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: Colors.grey[400],
                size: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
