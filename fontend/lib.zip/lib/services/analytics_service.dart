import 'api_service.dart';

class AnalyticsService {
  /// Fetches coordinator overview analytics for dashboards.
  ///
  /// Backend route: GET /api/analytics/coordinator/overview
  static Future<Map<String, dynamic>> getCoordinatorOverview() async {
    return await ApiService.get('/analytics/coordinator/overview');
  }
}



